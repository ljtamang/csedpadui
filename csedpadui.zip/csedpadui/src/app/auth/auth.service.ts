import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }

  login(username: string, password: string): Observable<{ username: string;}> {
    /*
      This will pressumably call a http backend and return the response
      return this.http.post<{{ name: string; email: string }}>(url, { email: email, password: password })
      .pipe(
        map(res => res.body)
      )
      */

    return of({
      username: 'some-token'
    });
  }

  logout(): Observable<null> {
    return of(null);
  }
}
}
